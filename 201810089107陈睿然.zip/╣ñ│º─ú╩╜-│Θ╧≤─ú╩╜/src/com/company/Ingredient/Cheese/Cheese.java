package com.company.Ingredient.Cheese;

/**
 * 芝士抽象类
 */
public abstract class Cheese {
}
