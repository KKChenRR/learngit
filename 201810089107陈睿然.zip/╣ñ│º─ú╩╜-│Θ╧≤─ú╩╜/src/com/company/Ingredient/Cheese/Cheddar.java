package com.company.Ingredient.Cheese;

/**
 * 英国芝士
 */
public class Cheddar extends Cheese{
    public Cheddar(){
        System.out.println("Cheddar material is going to be got ready....done");
    }
}
