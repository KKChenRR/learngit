package com.company.Ingredient.Cheese;

/**
 * 意大利芝士
 */
public class Mozzarella {
    public Mozzarella(){
        System.out.println("Mozzarella material is going to be got ready....done");
    }
}
