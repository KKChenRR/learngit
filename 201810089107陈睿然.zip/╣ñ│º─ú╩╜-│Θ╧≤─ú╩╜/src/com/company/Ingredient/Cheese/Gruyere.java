package com.company.Ingredient.Cheese;

/**
 * 瑞士芝士
 */
public class Gruyere extends Cheese {
    public Gruyere(){
        System.out.println("Gruyere material is going to be got ready....done");
    }
}
