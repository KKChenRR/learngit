package com.company.Ingredient.Meat;

/**
 * 猪肉
 */
public class Pork extends Meat {
    public Pork(){
        System.out.println("Pork material is going to be got ready....done");
    }
}
