package com.company.Ingredient.Meat;

/**
 * 鸡肉
 */
public class Chicken extends Meat {
    public Chicken(){
        System.out.println("Chicken material is going to be got ready....done");
    }
}
