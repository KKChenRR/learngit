package com.company.Ingredient.Meat;

/**
 * 牛肉
 */
public class Beef extends Meat{
    public Beef(){
        System.out.println("Beef material is going to be got ready....done");
    }
}
