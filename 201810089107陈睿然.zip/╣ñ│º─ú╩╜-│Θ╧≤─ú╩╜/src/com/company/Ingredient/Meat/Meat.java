package com.company.Ingredient.Meat;

/**
 * 肉抽象类
 */
public abstract class Meat {

}
