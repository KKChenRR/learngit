package com.company.Ingredient.Bread;

/**
 * 面包抽象类
 */
public abstract class Bread {
}
