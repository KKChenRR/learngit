package com.company.Ingredient.Bread;

/**
 * 麦面包
 */
public class WheatBread extends Bread {
    public WheatBread(){
        System.out.println("WheatBread material is going to be got ready....done");
    }
}
