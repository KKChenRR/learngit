package com.company.Ingredient.Bread;

/**
 * 玉米面包
 */
public class CornBread extends Bread{
    public CornBread(){
        System.out.println("WheatBread material is going to be got ready....done");
    }
}
