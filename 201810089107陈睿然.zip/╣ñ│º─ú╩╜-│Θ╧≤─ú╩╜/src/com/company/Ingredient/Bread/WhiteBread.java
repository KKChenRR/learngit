package com.company.Ingredient.Bread;

/**
 * 白面包
 */
public class WhiteBread extends Bread {
    public WhiteBread()
    {
        System.out.println("WhiteBread material is going to be got ready....done");
    }
}
