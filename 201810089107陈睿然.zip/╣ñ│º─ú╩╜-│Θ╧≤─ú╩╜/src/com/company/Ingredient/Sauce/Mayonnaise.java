package com.company.Ingredient.Sauce;

/**
 * 蛋黄酱
 */

public class Mayonnaise extends Sauce{
    public Mayonnaise(){
        System.out.println("Mayonnaise material is going to be got ready....done");
    }
}
