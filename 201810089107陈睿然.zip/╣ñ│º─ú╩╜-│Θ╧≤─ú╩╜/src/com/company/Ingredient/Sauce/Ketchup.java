package com.company.Ingredient.Sauce;

/**
 * 番茄酱
 */
public class Ketchup extends Sauce {
    public Ketchup(){
        System.out.println("Ketchup material is going to be got ready....done");
    }
}
