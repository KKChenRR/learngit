package com.company.Ingredient.Sauce;

/**
 * 酱抽象类
 */
public abstract class Sauce {
}
